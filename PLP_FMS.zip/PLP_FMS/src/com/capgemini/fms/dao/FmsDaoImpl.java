package com.capgemini.fms.dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.fms.bean.Feedback;

public class FmsDaoImpl implements IFmsDao {
	
	Connection con=Connect.getConnection();
	PreparedStatement pstmt;

	@Override
	public String doLogin(int userId, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Integer> getEnrolledCourse(int userId) {
		
		ArrayList<Integer> enrolledCourses=new ArrayList<Integer>();
	
		
		try {
			pstmt=con.prepareStatement(QueryMapper.FETCH_ENROLLED_COURSES);
			pstmt.setInt(1, userId);
			ResultSet res=pstmt.executeQuery();
			
				
			while(res.next())
			{
				enrolledCourses.add(res.getInt(1));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return enrolledCourses;
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public Boolean addFeedback(Feedback feedback) {
			int res=0;
		try {
			pstmt=con.prepareStatement(QueryMapper.INSERT_FEEDBACK);
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getPrsComm());
			pstmt.setInt(4, feedback.getClrfyDbts());
			pstmt.setInt(5, feedback.getTm());
			pstmt.setInt(6, feedback.getHndOut());
			pstmt.setInt(7, feedback.getHwSwNtwrk());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());
			
			res=pstmt.executeUpdate();
			if(res>0)
			{
				pstmt=con.prepareStatement(QueryMapper.UPDATE_FLAG);
				pstmt.setInt(1, feedback.getTrainingCode());
				pstmt.setInt(2, feedback.getParticipantId());
				int res1=pstmt.executeUpdate();
				System.out.println("resss" + res1);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res>0)
			
			
			
			
			return true;
		return false;
	}


}
