package com.capgemini.fms.dao;

public interface QueryMapper {
	public static final String FETCH_ENROLLED_COURSES="Select training_code from participant_enrollment where participant_id=? AND feedback_flag=0";
	
	public static final String INSERT_FEEDBACK="insert into feedback_master values(?,?,?,?,?,?,?,?,?)";
	
	public static final String COMPLETED_FEEDBACK="Select training_code from participant_enrollment where participant_id=? AND feedback_flag=1 ";
	public static final String UPDATE_FLAG="update participant_enrollment set feedback_flag=1 where training_code=? AND participant_id=?";
}
