package com.capgemini.fms.dao;

import java.util.ArrayList;

import com.capgemini.fms.bean.Feedback;

public interface IFmsDao {

	String doLogin(int userId, String password);

	ArrayList<Integer> getEnrolledCourse(int userId);

	Boolean addFeedback(Feedback feedback);

}
