package com.capgemini.fms.service;

import java.util.ArrayList;

import com.capgemini.fms.bean.Feedback;

public interface FmsService {

	String doLogin(int userId, String password);

	ArrayList<Integer> getEnrolledCourses(int userId);

	boolean validateRating(int rating);

	Boolean addFeedback(Feedback feedback);

}
