package com.capgemini.fms.service;

import java.util.ArrayList;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.FmsDaoImpl;
import com.capgemini.fms.dao.IFmsDao;

public class FmsServiceImpl implements FmsService {

	IFmsDao fmsDao = new FmsDaoImpl();

	@Override
	public String doLogin(int userId, String password) {

		return fmsDao.doLogin(userId, password);
	}

	@Override
	public ArrayList<Integer> getEnrolledCourses(int userId) {
		// TODO Auto-generated method stub
		return fmsDao.getEnrolledCourse(userId);
	}

	@Override
	public boolean validateRating(int rating) {

		if (rating > 0 && rating < 6)
			return true;

		return false;
		// TODO Auto-generated method stub

	}

	@Override
	public Boolean addFeedback(Feedback feedback) {
		return fmsDao.addFeedback(feedback);
	}
}
