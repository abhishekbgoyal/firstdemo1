package com.capgemini.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FmsService;
import com.capgemini.fms.service.FmsServiceImpl;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static FmsService fmsService = new FmsServiceImpl();
	static int userId=1001;
	
	public static void main(String[] args) {
		
		/*String role = login();
		if(role.equalsIgnoreCase("admin")){
		}
		else if(role.equalsIgnoreCase("coordinator")){
			viewCoordinatorPage();
		}
		else if(role.equalsIgnoreCase("participant")){
			viewParticpantPage();
		}
		else{
			
		}*/
		viewParticpantPage();
	}
	
	private static void viewCoordinatorPage() {
		// TODO Auto-generated method stub
		
	}

	public static void viewParticpantPage() {
		// TODO Auto-generated method stub
		
		System.out.println("Courses assigned to you are:");
		ArrayList<Integer> enrolledCourses=fmsService.getEnrolledCourses(userId);
		System.out.println(enrolledCourses);
		System.out.println("Enter the training Code for which you want to submit feedback");
		int trainingCode=sc.nextInt();
		Feedback feedback=new Feedback();
		
		feedback.setTrainingCode(trainingCode);
		feedback.setParticipantId(userId);
		int rating=0;
		boolean validated=true;
		do
		{
			System.out.println("Rate the course on basis of Pre & Comm");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setPrsComm(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of Doubt Clarification");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setClrfyDbts(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of Time Management");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else 
				feedback.setTm(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on basis of handouts");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setHndOut(rating);
		}
		while(!validated);
		do
		{
			System.out.println("Rate the course on usage of HW/SW Resources");
			rating=sc.nextInt();
			validated=fmsService.validateRating(rating);
			if(!validated)
				System.out.println("Invalid Value Please enter rating as 1,2,3,4,5");
			else
				feedback.setHwSwNtwrk(rating);
		}
		while(!validated);
		sc.nextLine();
		System.out.println("Comments regarding the Course");
		feedback.setComments(sc.nextLine());
		System.out.println("Enter any suggestion");
		feedback.setSuggestions(sc.nextLine());
		
		System.out.println("FeedBack Entered by you is :\n"+ feedback.toString());
		
		Boolean feedbackStatus=fmsService.addFeedback(feedback);
		System.out.println(feedbackStatus);
		
		
	}

	public static String login(){
		System.out.println("Please enter your Employee ID:");
		userId = sc.nextInt();
		System.out.println("Please enter your password:");
		String password = sc.next();

		String role = fmsService.doLogin(userId, password);
		return role;
	}
	

}


