package com.capgemini.fms.bean;

public class Feedback {

	private int trainingCode;
	private int participantId;
	private int prsComm;
	private int clrfyDbts;
	private int tm;
	private int hndOut;
	private int hwSwNtwrk;
	private String comments;
	private String suggestions;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getPrsComm() {
		return prsComm;
	}
	public void setPrsComm(int prsComm) {
		this.prsComm = prsComm;
	}
	public int getClrfyDbts() {
		return clrfyDbts;
	}
	public void setClrfyDbts(int clrfyDbts) {
		this.clrfyDbts = clrfyDbts;
	}
	public int getTm() {
		return tm;
	}
	public void setTm(int tm) {
		this.tm = tm;
	}
	public int getHndOut() {
		return hndOut;
	}
	public void setHndOut(int hndOut) {
		this.hndOut = hndOut;
	}
	public int getHwSwNtwrk() {
		return hwSwNtwrk;
	}
	public void setHwSwNtwrk(int hwSwNtwrk) {
		this.hwSwNtwrk = hwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	public Feedback(int trainingCode, int participantId, int prsComm,
			int clrfyDbts, int tm, int hndOut, int hwSwNtwrk, String comments,
			String suggestions) {
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.prsComm = prsComm;
		this.clrfyDbts = clrfyDbts;
		this.tm = tm;
		this.hndOut = hndOut;
		this.hwSwNtwrk = hwSwNtwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	public Feedback() {
	}
	@Override
	public String toString() {
		return "Feedback [trainingCode=" + trainingCode + ", participantId="
				+ participantId + ", prsComm=" + prsComm + ", clrfyDbts="
				+ clrfyDbts + ", tm=" + tm + ", hndOut=" + hndOut
				+ ", hwSwNtwrk=" + hwSwNtwrk + ", comments=" + comments
				+ ", suggestions=" + suggestions + "]";
	}
	
	
}
